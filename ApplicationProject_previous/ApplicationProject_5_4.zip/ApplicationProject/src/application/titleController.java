/**
 * 
 */
package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Region;
import javafx.scene.paint.ImagePattern;

/**
 * @author oep957
 *
 */
public class titleController 
{
	
	/**Event handler for when the slap jack button is clicked. We are changing the fxml to the SlapJAckScreen.fxml
	 * @param event Action Event
	 */
	@FXML
	private void handle(ActionEvent event)
    {
		Main.url=Main.class.getResource("/fxml/SlapJackScreen.fxml");
		Main.loader.setLocation(Main.url);	
        try {
			Main.scene.setRoot(FXMLLoader.load(getClass().getResource("/fxml/SlapJackScreen.fxml")));
			Main.root=(AnchorPane)Main.loader.load();

			Main.stage.setScene(Main.scene);
			Main.stage.setTitle("Slap Jack"); //Changing the title of the primaryStage to better fit the purpose of the application
			Main.stage.show();
		
			System.out.println("Slap Jack");
		}
        catch (IOException e) 
        {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//Connecting to the FXML
		 
    }
	
	/**Action Handler for when the war button is clicked. Changing the fxml to the warScreen.fxml
	 * @param event ActionEvent
	 */
	@FXML
	private void handleWar(ActionEvent event)
    {
		
		Main.url=Main.class.getResource("/fxml/warScreen.fxml");
		Main.loader.setLocation(Main.url);	
        try {
			Main.scene.setRoot(FXMLLoader.load(getClass().getResource("/fxml/warScreen.fxml")));
			Main.root=(AnchorPane)Main.loader.load();

			Main.stage.setScene(Main.scene);
			Main.stage.setTitle("War"); //Changing the title of the primaryStage to better fit the purpose of the application
			Main.stage.show();
		
			System.out.println("war");
		}
        catch (IOException e) 
        {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//Connecting to the FXML
		 
		 
    }
	
	
	/**Action Handler for when the Beggar My Neighbor game. We will change the fxml to BeggarMyNeighbor.fxml
	 * @param event ActionEvent 
	 * @throws IOException
	 */
	@FXML
	private void handlePlayBMN(ActionEvent event) throws IOException
    {
		Main.url=Main.class.getResource("/fxml/BeggarMyNeighbor.fxml");
		Main.loader.setLocation(Main.url);	
        try {
        	
			Main.scene.setRoot(FXMLLoader.load(getClass().getResource("/fxml/BeggarMyNeighbor.fxml")));
		    Parent root = Main.scene.getRoot();
		    BackgroundImage background= new BackgroundImage(new Image("/images/greenbg.jpg"), BackgroundRepeat.NO_REPEAT, null, BackgroundPosition.CENTER, new BackgroundSize(1.0, 1.0, true, true, false, false));
		    ((Region) root).setBackground(new Background(background));
			Main.scene.getStylesheets().add(getClass().getResource("/css/BeggarMyNeighbor.css").toExternalForm());
			Main.stage.setScene(Main.scene);
			Main.stage.setTitle("BeggarMyNeighbor"); //Changing the title of the primaryStage to better fit the purpose of the application
			Main.stage.setHeight(800);
			Main.stage.setWidth(800);
			Main.stage.setResizable(false);
			Main.stage.show();
			
		}
        catch (IOException e) 
        {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//Connecting to the FXML
		  
    }
	
	
}
