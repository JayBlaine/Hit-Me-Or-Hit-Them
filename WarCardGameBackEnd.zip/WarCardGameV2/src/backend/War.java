package backend;

import java.util.LinkedList;
import java.util.Queue;

public class War { //made this class because didn't want a static method in driver -> only allowed static methods there so VVVVV

	public War() { /// should have constructor but left it empty bc?? What would you put in here
		
	}
	//problem is if there are only four cards left and the last four are the same then ?? 
	//should I remove WinDeck and just put the win into the regular deck card 3/18/2020
	
	public Queue<Card> war(Queue<Card> playerDeck, Queue<Card> compDeck, String inputFlip) {
		Queue<Card> compWarDeck = new LinkedList<Card>();
		Queue<Card> playerWarDeck = new LinkedList<Card>();
		
			if(inputFlip.equalsIgnoreCase("fff")) {
				playerWarDeck.add(playerDeck.remove());//remove the first flipped
				playerWarDeck.add(playerDeck.remove());
				playerWarDeck.add(playerDeck.remove());
				playerWarDeck.add(playerDeck.remove());
	
				compWarDeck.add(compDeck.remove());//removed the first flipped
				compWarDeck.add(compDeck.remove());
				compWarDeck.add(compDeck.remove());
				compWarDeck.add(compDeck.remove());
					
					if(compWarDeck.peek().getRank()>playerWarDeck.peek().getRank()) {
						compDeck.addAll(compWarDeck);
						compDeck.addAll(playerWarDeck);
						System.out.println("CPU card is higher, CPU takes the cards!");
						return compDeck;
		
					}
					else if(compWarDeck.peek().getRank()>playerWarDeck.peek().getRank()) {
						playerDeck.addAll(compWarDeck);
						playerDeck.addAll(playerWarDeck);
						System.out.println("Player card is higher, Player takes the cards!");
						return playerDeck;
					}
					else if(compWarDeck.peek().getRank()==playerWarDeck.peek().getRank()) {
						war(playerDeck, compDeck, inputFlip);
					}
			}
		
		return null;

	}
}
	


