package backend;

import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;




//problem is with "WAR" part, line 79-------- along with line 92 which calls the only method in War class to ?? ushh WAR???  3/20/2020


public class Driver {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		ArrayList<Card> deckOfCards = new ArrayList<Card>(52);
		Queue<Card> playerDeck = new LinkedList<Card>();
		Queue<Card> compDeck = new  LinkedList<Card>();
		Queue<Card> playerWinDeck = new LinkedList<Card>();
		Queue<Card> compWinDeck = new LinkedList<Card>();
		War game = new War();

		for(int j=1; j<14; j++)							//add Cards to deckOfCards
			deckOfCards.add(new Card(j, "Spades"));
		for(int j=1; j<14; j++)
			deckOfCards.add(new Card(j, "Hearts"));
		for(int j=1; j<14; j++)
			deckOfCards.add(new Card(j, "Diamonds"));
		for(int j=1; j<14; j++)
			deckOfCards.add(new Card(j, "Clubs"));
		
		Collections.shuffle(deckOfCards);
		
		for(int i = 0; i<deckOfCards.size(); i++) {	//split the deck 
			if(i%2 == 0) {
				playerDeck.add(deckOfCards.get(i));
			}else {
				compDeck.add(deckOfCards.get(i));
			}
		}
		//////////////////////////////////////////////////////////////////////////
		String inputFlip;
		Scanner scan = new Scanner(System.in);
		do {
	
			System.out.println("Type \"f\" to flip card");
			inputFlip = scan.next();
			
			if(inputFlip.equalsIgnoreCase("F")) {
				
				System.out.println("Player card is " + playerDeck.peek());
				System.out.println("CPU card is " + compDeck.peek());

				if(playerDeck.peek().getRank()>compDeck.peek().getRank()) {
					System.out.println("Your card beats CPU's card!");
					//add to win deck with the removed OG deck
					playerWinDeck.add(playerDeck.remove());
					playerWinDeck.add(compDeck.remove());
					System.out.println("                                           Player Deck Size " + playerDeck.size() + "\t\t\tPlayer Win Deck Size " + playerWinDeck.size());
					System.out.println("                                           Comp Deck Size " + compDeck.size() + "\t\t\tComp Win Deck Size " + compWinDeck.size());

				}
				else if(playerDeck.peek().getRank()<compDeck.peek().getRank()){
					System.out.println("CPU's card beats your card!");
					//add to win deck with the removed OG deck
					compWinDeck.add(playerDeck.remove());
					compWinDeck.add(compDeck.remove());
					System.out.println("                                           Player Deck Size " + playerDeck.size() + "\t\t\tPlayer Win Deck Size " + playerWinDeck.size());
					System.out.println("                                           Comp Deck Size " + compDeck.size() + "\t\t\tComp Win Deck Size " + compWinDeck.size());

				}
				else if(playerDeck.peek().getRank()==compDeck.peek().getRank()) {
					System.out.println("The cards are the same rank! War has been declared!");
					System.out.println("Type \"fff\" flip three cards!");
					inputFlip = scan.next();

					if(playerDeck.size() < 4) {
						compDeck.addAll(playerDeck);		
						System.out.println("Player ran out of cards");
					}
					else if(compDeck.size() < 4) {
						playerDeck.addAll(compDeck);
						System.out.println("CPU ran out of cards");
					}else {
					game.war(playerDeck, compDeck, inputFlip);		
					System.out.println("                                           Player Deck Size " + playerDeck.size() + "             Player Win Deck Size " + playerWinDeck.size());
					System.out.println("                                           Comp Deck Size " + compDeck.size() + "                 Comp Win Deck Size " + compWinDeck.size());

					}
				}
				
			}else {
				System.out.println("this is not an option, game terminated.");
			}
			
			//base case
			if(playerDeck.isEmpty()) {						//Checks to see if deck is empty, if empty then CPU wins
				if(playerWinDeck.isEmpty()) {
					System.out.println("CPU Wins");
				}
				else {
					playerDeck.addAll(playerWinDeck);
				}
			}
			else if(compDeck.isEmpty()) {					//Checks to see if deck is empty, if empty then Player Wins
				if(compWinDeck.isEmpty()) {
					System.out.println("Player Wins!");
				}else {
					compDeck.addAll(compWinDeck);
				}
			}
		}while(!playerDeck.isEmpty() && !compDeck.isEmpty());
		
							
		
		
	}//end of main 	
	
	
	
}//end of driver































