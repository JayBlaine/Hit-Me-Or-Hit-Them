package application;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import backend.Card;
import javafx.event.ActionEvent;

import javafx.scene.control.Label;

import javafx.scene.shape.Rectangle;

public class DrawCardsController implements Initializable {
	
	
	@FXML
	private Rectangle compCardWar1, compCardWar2, compCardWar3, playerCardWar1, playerCardWar2, playerCardWar3, deck, playerCard,compCard, playerDeck, compDeck;
	@FXML			//No usage of button I just learned how to draw and put the image into a button first and it worked soooo--- 
	private Button buttonDiamondPlayerDeck, buttonHeartArrowPlayerDeck, buttonHeartPlayerDeck, buttonLeafPlayerDeck, buttonLeafCompDeck, buttonHeartCompDeck,
					buttonHeartArrowCompDeck, buttonDiamondCompDeck, buttonLeafPlayerDeck1, buttonHeartPlayerDeck1, buttonHeartArrowPlayerDeck1, buttonDiamondPlayerDeck1,
					buttonDiamondCompDeck1, buttonHeartArrowCompDeck1, buttonHeartCompDeck1, buttonLeafCompDeck1;
	@FXML
	private Label playerDeckTopNumber, playerDeckBottomNumber, playerWarCard3Bottom, playerWarCard3, playerWarCard1, playerWarCard2, compDeckBottomNumber, compDeckTopNumber,
				  compWarCard2, compWarCard1, compWarCard3, compWarCard3Bottom, flipCardLabel;
	@FXML
	private Button play, deal;

	
	
	@FXML
	public void handlePlay(ActionEvent event) {
		play.setVisible(false);
		deck.setVisible(true);
		deal.setVisible(true);
	}
	@FXML
	public void handleDeal(ActionEvent event) {
		deal.setVisible(false);
		deck.setVisible(false);
		compCard.setVisible(true);
		playerCard.setVisible(true);
	}
	
	@FXML
	public void handleCardFlip(ActionEvent event){
	}
	
	public void initialize(URL url, ResourceBundle rb) {
			hide();
			
	}
	
	
	
	
	
	//create a method that hides everything for beginning of game
	private void hide() {

		
		deal.setVisible(false);
		
		compDeck.setVisible(false);
		playerDeck.setVisible(false);
		flipCardLabel.setVisible(false);
		
		compCardWar1.setVisible(false);
		compCardWar2.setVisible(false);
		compCardWar3.setVisible(false);
		playerCardWar1.setVisible(false);
		playerCardWar2.setVisible(false);
		playerCardWar3.setVisible(false);
		playerCard.setVisible(false);
		compCard.setVisible(false);
		deck.setVisible(false);
		
		buttonDiamondPlayerDeck.setVisible(false);
		buttonHeartArrowPlayerDeck.setVisible(false);
		buttonHeartPlayerDeck.setVisible(false);
		buttonLeafPlayerDeck.setVisible(false);
		buttonLeafCompDeck.setVisible(false);
		buttonHeartCompDeck.setVisible(false);
		buttonHeartArrowCompDeck.setVisible(false);
		buttonDiamondCompDeck.setVisible(false);
		buttonLeafPlayerDeck1.setVisible(false);
		buttonHeartPlayerDeck1.setVisible(false);
		buttonHeartArrowPlayerDeck1.setVisible(false);
		buttonDiamondPlayerDeck1.setVisible(false);
		buttonDiamondCompDeck1.setVisible(false);
		buttonHeartArrowCompDeck1.setVisible(false);
		buttonHeartCompDeck1.setVisible(false);
		buttonLeafCompDeck1.setVisible(false);
		
		playerDeckTopNumber.setVisible(false);
		playerDeckBottomNumber.setVisible(false);
		playerWarCard3Bottom.setVisible(false);
		playerWarCard3.setVisible(false);
		playerWarCard1.setVisible(false);
		playerWarCard2.setVisible(false);
		compDeckBottomNumber.setVisible(false);
		compDeckTopNumber.setVisible(false);
		compWarCard2.setVisible(false);
		compWarCard1.setVisible(false);
		compWarCard3.setVisible(false);
		compWarCard3Bottom.setVisible(false);
		
		
		
	}
	
	//create a method that hides war cards and its numbers						//Do i really need this??? 
	private void hideWar() {
		compCardWar1.setVisible(false);
		compCardWar2.setVisible(false);
		compCardWar3.setVisible(false);
		playerCardWar1.setVisible(false);
		playerCardWar2.setVisible(false);
		playerCardWar3.setVisible(false);
	}
	
	
	//create a method that hides player card number
	private void hidePlayerCarNumber() {
		
	}
	
	//create method that hides comp card number
	private void hideCompCardNumber() {
		
	}
	
}
